#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <windows.h>
#include <limits>
#include <algorithm>
#include <cctype>
#include <ctime>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <conio.h>
#include <locale>

//CLASS FOR ACCOUNTS
class nbg_account {
public:
    std::string first_name, last_name, username, password, iban;
    long double balance;
    int card_number[16], iban_numbers[5];

    nbg_account() {
        first_name = "none";
        last_name = "none";
        username = "none";
        password = "none";
        balance = 0.00;
        srand(time(NULL));
        for (int i = 0; i < 16; i++) {
            card_number[i] = rand() % 9;
        }
        for (int i = 0; i < 5; i++) {
            iban_numbers[i] = rand() % 89999 + 10000;
        }
        iban = "GR" + std::to_string(iban_numbers[0]) + std::to_string(iban_numbers[1]) + std::to_string(iban_numbers[2]) + std::to_string(iban_numbers[3]) + std::to_string(iban_numbers[4]);
    }
};
//CLASS FOR TRANSACTIONS
class transactions :public nbg_account {
public:
    std::string code;
    std::string timedate;
    std::string category;
    std::string owner;
    std::string username2;
    double amount;
    transactions() {
        // ���� ��� ��������� ����������� ��� ����
        std::time_t currentTime = std::time(nullptr);
        std::tm localTime;
        localtime_s(&localTime, &currentTime);

        // ��������� ��� ����������� ��� ���� �� ����� C-style string
        char buffer[80];
        std::strftime(buffer, sizeof(buffer), "%d/%m/%Y %H:%M:%S", &localTime);
        code = "0";
        timedate = buffer;
        category = "NONE";
        username2 = "NONE";
        amount = 0;
    }
};
class money_boxes : public nbg_account {
    public:
        std::string box_name;
        double end_amount,today_amount;
        std::string category;
        std::string date;
        std::string user;
        money_boxes() {
            box_name = "none";
            end_amount = 0;
            today_amount = 0;
            category = "none";
            date = "00/00/0000";
            user = "none";

        }
};
//FORM X,Y
const int FORM_HEIGHT = 3;
const int FORM_WIDTH = 23;
//DEPOSIT,WITHDRAW X,Y
const int DEP_HEIGHT = 17;
const int DEP_WIDTH = 49;
//TRANSFER X,Y
const int TRANSFER_HEIGHT = 20;
const int TRANSFER_WIDTH = 49;

//MONEY BOX X,Y
const int MBOX_HEIGHT = 14;
const int MBOX_WIDTH = 33;

char form[FORM_HEIGHT][FORM_WIDTH];
char depos[DEP_HEIGHT][DEP_WIDTH];
char withdr[DEP_HEIGHT][DEP_WIDTH];
char transfr[TRANSFER_HEIGHT][TRANSFER_WIDTH];
char mbox[MBOX_HEIGHT][MBOX_WIDTH];

//Getting the moneyboxes.txt into a table
void get_moneybox() {
    int i, j;
    std::ifstream inputfile("money_box.txt");
    if (inputfile.is_open()) {
        std::string line;
        int line_number = 0;

        while (std::getline(inputfile, line) && line_number < MBOX_HEIGHT) {
            for (j = 0; j < line.length() && j < MBOX_WIDTH; j++) {
                mbox[line_number][j] = line[j];
            }
            line_number++;
        }

        inputfile.close();
    }
    else {
        std::cout << "File could not open..." << std::endl;
    }
}
//Getting the transfer.txt into a table
void get_transfer() {
    int i, j;
    std::ifstream inputfile("transfer.txt");
    if (inputfile.is_open()) {
        std::string line;
        int line_number = 0;

        while (std::getline(inputfile, line) && line_number < TRANSFER_HEIGHT) {
            for (j = 0; j < line.length() && j < TRANSFER_WIDTH; j++) {
                transfr[line_number][j] = line[j];
            }
            line_number++;
        }

        inputfile.close();
    }
    else {
        std::cout << "File could not open..." << std::endl;
    }
}
//Getting the withdraw.txt into a table
void get_withdraw() {
    int i, j;
    std::ifstream inputfile("withdraw.txt");
    if (inputfile.is_open()) {
        std::string line;
        int line_number = 0;

        while (std::getline(inputfile, line) && line_number < DEP_HEIGHT) {
            for (j = 0; j < line.length() && j < DEP_WIDTH; j++) {
                withdr[line_number][j] = line[j];
            }
            line_number++;
        }

        inputfile.close();
    }
    else {
        std::cout << "File could not open..." << std::endl;
    }
}
//Getting the deposit.txt into a table
void get_deposit() {
    int i, j;
    std::ifstream inputfile("deposit.txt");
    if (inputfile.is_open()) {
        std::string line;
        int line_number = 0;

        while (std::getline(inputfile, line) && line_number < DEP_HEIGHT) {
            for (j = 0; j < line.length() && j < DEP_WIDTH; j++) {
                depos[line_number][j] = line[j];
            }
            line_number++;
        }

        inputfile.close();
    }
    else {
        std::cout << "File could not open..." << std::endl;
    }
}
//Getting the form.txt into a table
void get_form() {
    int i, j;
    std::ifstream inputfile("form.txt");
    if (inputfile.is_open()) {
        std::string line;
        int line_number = 0;

        while (std::getline(inputfile, line) && line_number < FORM_HEIGHT) {
            for (j = 0; j < line.length() && j < FORM_WIDTH; j++) {
                form[line_number][j] = line[j];
            }
            line_number++;
        }

        inputfile.close();
    }
    else {
        std::cout << "File could not open..." << std::endl;
    }
}
//loading screen when the app starts
void open_loading_screen() {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");
    SetConsoleCP(437);
    SetConsoleOutputCP(437);
    int bar1 = 177, bar2 = 219;

    std::cout << "\n\n\n\t\t\t\t\t\tNATIONAL BANK OF GREECE\n\n\n\n";
    std::cout << "\t\t\t\t\t\tLoading...";
    std::cout << "\n\n\n\t\t\t\t\t\t";

    for (int i = 0; i < 25; i++) {
        std::cout << static_cast<char>(bar1);
    }

    std::cout << "\r";
    std::cout << "\t\t\t\t\t\t";

    for (int i = 0; i < 25; i++) {
        std::cout << static_cast<char>(bar2);
        Sleep(150);
    }
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
}
//create account form-page
void create_account(nbg_account& new_account, nbg_account& logged_account) {
    int i, j;
    std::string submit;
    COORD coordinates;

    do {
        system("cls");
        std::cout << "\n\t\t\t\t\t\tNATIONAL BANK OF GREECE";
        std::cout << "\n\n\t\t\t\t\t\tCreate an NBG Account";
        std::cout << "\n\n\t\t\t\t\t\tFirst Name(required) : ";

        for (i = 0; i < 3; i++) {
            std::cout << "\n\t\t\t\t\t\t";
            for (j = 0; j < 23; j++) {
                std::cout << form[i][j];
            }
        }

        std::cout << "\n";
        std::cout << "\n\t\t\t\t\t\tLast Name(required) : ";

        for (i = 0; i < 3; i++) {
            std::cout << "\n\t\t\t\t\t\t";
            for (j = 0; j < 23; j++) {
                std::cout << form[i][j];
            }
        }

        std::cout << "\n";
        std::cout << "\n\t\t\t\t\t\tUsername(required) : ";

        for (i = 0; i < 3; i++) {
            std::cout << "\n\t\t\t\t\t\t";
            for (j = 0; j < 23; j++) {
                std::cout << form[i][j];
            }
        }

        std::cout << "\n";
        std::cout << "\n\t\t\t\t\t\tPassword(required) : ";

        for (i = 0; i < 3; i++) {
            std::cout << "\n\t\t\t\t\t\t";
            for (j = 0; j < 23; j++) {
                std::cout << form[i][j];
            }
        }

        std::cout << "\n";
        std::cout << "\n\t\t\t\t\t\tCREATE(TYPE 'YES') : ";
        std::cout << "\n";

        coordinates.X = 52;
        coordinates.Y = 7;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);

        if (new_account.first_name == "none") {
            std::cin >> new_account.first_name;
        }
        else {
            std::cout << new_account.first_name;
        }

        coordinates.Y = 12;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);

        if (new_account.last_name == "none") {
            std::cin >> new_account.last_name;
        }
        else {
            std::cout << new_account.last_name;
        }

        coordinates.Y = 17;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);

        if (new_account.username == "none") {
            std::cin >> new_account.username;
        }
        else {
            std::cout << new_account.username;
        }

        coordinates.Y = 22;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);

        if (new_account.password == "none") {
            std::cin >> new_account.password;
        }
        else {
            std::cout << new_account.password;
        }

        coordinates.X = 69;
        coordinates.Y = 25;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
        std::cin >> submit;
    } while (submit != "yes" && submit != "YES" && submit != "Yes" && submit != "YeS" && submit != "yES" && submit != "yEs");
    logged_account = new_account;
}
//save the accounts vector into the accounts.txt
void save_account(const std::vector<nbg_account>& accounts) {
    std::ofstream outfile("accounts.txt");
    if (outfile.is_open()) {
        for (const nbg_account account : accounts) {

            outfile << account.first_name << "," << account.last_name << "," << account.username << "," << account.password << "," << account.balance << ",";
            for (int i = 0; i < 16; i++) {
                outfile << account.card_number[i] << ",";
            }
            outfile << account.iban << "\n";


        }
        outfile.close();
    }
    else {
        std::cout << "Error: Unable to save accounts." << std::endl;
    }
}
//save the transactions vector into the transactions.txt
void save_transactions(const std::vector<transactions>& trans, std::string t_code, char dep, nbg_account logged_account, double amount) {
    std::ofstream outfile("transactions.txt");
    if (outfile.is_open()) {

        for (const transactions& tran : trans) {
            outfile << tran.username << "," << tran.username2 << "," << tran.timedate << "," << tran.code << "," << tran.category << "," << tran.amount << "\n";
        }

        outfile.close();

    }

}
//save the money box vector into the moneyboxes.txt
void save_moneyboxes(std::vector<money_boxes>& boxes,nbg_account logged_account) {
    std::ofstream outfile("moneyboxes.txt");
    if (outfile.is_open()) {

        for (money_boxes& box : boxes) {
            outfile << box.box_name << "," << box.category << "," << box.end_amount << "," << box.today_amount << "," << box.date << "," << logged_account.username;
        }

        outfile.close();

    }

}
//taking the information from moneyboxes.txt and fill up the moneyboxes vector
void load_moneyboxes(std::vector<money_boxes> &boxes) {
    std::ifstream infile("moneyboxes.txt");
    if (infile.is_open()) {
        std::string line;
        while (std::getline(infile, line)) {
            money_boxes box;
            size_t pos = 0;
            std::string token;


            for (int i = 0; i < 6; i++) {
                pos = line.find(",");
                token = line.substr(0, pos);
                switch (i) {
                case 0:
                    box.box_name = token;
                    break;
                case 1:
                    box.category = token;
                    break;
                case 2:
                    box.end_amount = std::stold(token);
                    break;
                case 3:
                    box.today_amount = std::stold(token);
                    break;
                case 4:
                    box.date = token;
                    break;
                case 6:
                    box.user = token;
                    break;
                }
                line.erase(0, pos + 1);
            }
            boxes.push_back(box);
        }
        infile.close();
    }
    else {
        std::cout << "Error: Unable to load accounts." << std::endl;
    }
}
//taking the information from transactions.txt and fill up the transactions vector
void load_transactions(std::vector<transactions>& trans) {
    std::ifstream infile("transactions.txt");
    if (infile.is_open()) {
        std::string line;
        while (std::getline(infile, line)) {
            transactions tran;
            size_t pos = 0;
            std::string token;


            for (int i = 0; i < 6; i++) {
                pos = line.find(",");
                token = line.substr(0, pos);
                switch (i) {
                case 0:
                    tran.username = token;
                    break;
                case 1:
                    tran.username2 = token;
                    break;
                case 2:
                    tran.timedate = token;
                    break;
                case 3:
                    tran.code = token;
                    break;
                case 4:
                    tran.category = token;
                    break;
                case 5:
                    tran.amount = std::stold(token);
                    break;

                }
                line.erase(0, pos + 1);
            }
            trans.push_back(tran);
        }
        infile.close();
    }
    else {
        std::cout << "Error: Unable to load accounts." << std::endl;
    }
}
//taking the information from accounts.txt and fill up the accounts vector
void load_accounts(std::vector<nbg_account>& accounts) {
    std::ifstream infile("accounts.txt");
    if (infile.is_open()) {
        std::string line;
        while (std::getline(infile, line)) {
            nbg_account account;
            size_t pos = 0;
            std::string token;


            for (int i = 0; i < 22; i++) {
                pos = line.find(",");
                token = line.substr(0, pos);
                switch (i) {
                case 0:
                    account.first_name = token;
                    break;
                case 1:
                    account.last_name = token;
                    break;
                case 2:
                    account.username = token;
                    break;
                case 3:
                    account.password = token;
                    break;
                case 4:
                    account.balance = std::stold(token);
                    break;
                case 5:
                    account.card_number[i - 5] = std::stoll(token);
                    break;
                case 6:
                    account.card_number[i - 5] = std::stoll(token);
                    break;
                case 7:
                    account.card_number[i - 5] = std::stoll(token);
                    break;
                case 8:
                    account.card_number[i - 5] = std::stoll(token);
                    break;
                case 9:
                    account.card_number[i - 5] = std::stoll(token);
                    break;
                case 10:
                    account.card_number[i - 5] = std::stoll(token);
                    break;
                case 11:
                    account.card_number[i - 5] = std::stoll(token);
                    break;
                case 12:
                    account.card_number[i - 5] = std::stoll(token);
                    break;
                case 13:
                    account.card_number[i - 5] = std::stoll(token);
                    break;

                case 14:
                    account.card_number[i - 5] = std::stoll(token);
                    break;
                case 15:
                    account.card_number[i - 5] = std::stoll(token);
                    break;
                case 16:
                    account.card_number[i - 5] = std::stoll(token);
                    break;
                case 17:
                    account.card_number[i - 5] = std::stoll(token);
                    break;
                case 18:
                    account.card_number[i - 5] = std::stoll(token);
                    break;
                case 19:
                    account.card_number[i - 5] = std::stoll(token);
                    break;
                case 20:
                    account.card_number[i - 5] = std::stoll(token);
                    break;
                case 21:
                    account.iban = token;
                    break;
                }
                line.erase(0, pos + 1);
            }
            accounts.push_back(account);
        }
        infile.close();
    }
    else {
        std::cout << "Error: Unable to load accounts." << std::endl;
    }
}
//the loading screen when user creates successfully an account
void creating_loading(const nbg_account& new_account) {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");
    SetConsoleCP(437);
    SetConsoleOutputCP(437);
    int bar1 = 177, bar2 = 219;

    std::cout << "\n\n\n\t\t\t\t\t\tNATIONAL BANK OF GREECE\n\n\n\n";
    std::cout << "\t\t\t\t\t\tCreating Your Account...";
    std::cout << "\n\n\n\t\t\t\t\t\t";

    for (int i = 0; i < 25; i++) {
        std::cout << (char)bar1;
    }

    std::cout << "\r";
    std::cout << "\t\t\t\t\t\t";
    for (int i = 0; i < 25; i++) {
        std::cout << (char)bar2;
        Sleep(150);
    }

    system("cls");
    COORD coordinates;
    coordinates.X = 42;
    coordinates.Y = 8;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "ACOUNT CREATED!!";
    coordinates.Y = 10;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "WELCOME " << new_account.first_name;
    Sleep(2500);
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
}
//the loading screen when user successfully login to an account
void login_loading(nbg_account logged_account) {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");
    SetConsoleCP(437);
    SetConsoleOutputCP(437);
    int bar1 = 177, bar2 = 219;

    std::cout << "\n\n\n\t\t\t\t\t\tNATIONAL BANK OF GREECE\n\n\n\n";
    std::cout << "\t\t\t\t\t\tLogin in to your Account...";
    std::cout << "\n\n\n\t\t\t\t\t\t";

    for (int i = 0; i < 25; i++) {
        std::cout << (char)bar1;
    }

    std::cout << "\r";
    std::cout << "\t\t\t\t\t\t";
    for (int i = 0; i < 25; i++) {
        std::cout << (char)bar2;
        Sleep(150);
    }

    system("cls");
    COORD coordinates;
    coordinates.X = 42;
    coordinates.Y = 8;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "YOU SUCCESSFULLY LOGGED IN!!";
    coordinates.Y = 10;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "WELCOME " << logged_account.first_name;
    Sleep(2500);
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
}
//login form-page
void login(std::vector<nbg_account>& accounts, nbg_account& logged_account, int& acc_i) {
    std::string username, password;
    bool found = false;
    COORD coordinates;
    coordinates.X = 60;
    do {
        system("cls");
        std::cout << "\n\t\t\t\t\t\tNATIONAL BANK OF GREECE";
        std::cout << "\n\n\t\t\t\t\t\tLogin to Your Account";
        std::cout << "\n\n\n\t\t\t\t\t\tUsername : ";
        std::cout << "\n\n\n\t\t\t\t\t\tPassword : ";
        coordinates.Y = 6;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
        std::cin >> username;
        coordinates.Y = 9;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
        std::cin >> password;

        for (int i = 0; i < accounts.size(); i++) {
            if (accounts[i].username == username && accounts[i].password == password) {
                found = true;
                logged_account = accounts[i];
                acc_i = i;
                break;
            }
        }

        if (!found) {
            std::cout << "\n\t\t\t\t\t\tInvalid username or password. Please try again.\n";
            Sleep(2000);
        }
    } while (!found);
}
//home-page ,main page -show
void show_app(nbg_account& logged_account, std::vector<transactions> trans) {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");
    COORD coordinates;
    coordinates.X = 5;
    coordinates.Y = 3;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "NATIONAL BANK OF GREECE - NBG GROUP";
    coordinates.X = 5;
    coordinates.Y = 5;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::transform(logged_account.first_name.begin(), logged_account.first_name.end(), logged_account.first_name.begin(), [](unsigned char c) {
        return std::toupper(c);
        });
    std::transform(logged_account.last_name.begin(), logged_account.last_name.end(), logged_account.last_name.begin(), [](unsigned char c) {
        return std::toupper(c);
        });
    std::cout << logged_account.first_name << " " << logged_account.last_name;
    coordinates.X = 5;
    coordinates.Y = 8;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "Account IBAN";
    coordinates.X = 34;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << logged_account.iban;
    coordinates.X = 5;
    coordinates.Y = 10;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "Account Balance";
    coordinates.X = 34;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << logged_account.balance << "$";
    coordinates.X = 5;
    coordinates.Y = 12;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "Debit Mastercard";
    coordinates.X = 34;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    for (int i = 0; i < 16; i++) {
        if (i == 3 || i == 7 || i == 11 || i == 15) {
            std::cout << logged_account.card_number[i] << " ";
        }
        else {
            std::cout << logged_account.card_number[i];
        }
    }
    coordinates.X = 81;
    coordinates.Y = 3;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << " OPTIONS KEYS";
    coordinates.Y = 5;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << " Deposit - Press '1'";
    coordinates.Y = 7;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << " Withdraw - Press '2'";
    coordinates.Y = 9;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << " Recent Transactions - Press '3'";
    coordinates.Y = 11;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << " Transactions History - Press '4'";
    coordinates.Y = 13;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << " Transfer - Press '5'";
    coordinates.Y = 15;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << " Savings-Money Boxes - Press '6'";
    coordinates.Y = 17;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << " Create New Money Box - Press'7'";
    coordinates.Y = 19;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << " Statistics - Press'8'";
    coordinates.Y = 21;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << " Exit - Press'0'";


    coordinates.X = 69;
    coordinates.Y = 3;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 4;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 5;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 6;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 7;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 8;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 9;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 10;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 11;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 12;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 13;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 14;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 15;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 16;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 17;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 18;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 19;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 20;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";
    coordinates.Y = 21;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "|";

    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
}
//deposit form-page
void deposit(nbg_account& logged_account, std::vector<transactions>& trans, std::string& t_code, double& amount, transactions& new_tran, std::vector<nbg_account> accounts, int ti) {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");
    int i, j;
    COORD coordinates;

    coordinates.X = 40;
    coordinates.Y = 5;
    std::cout << "\n\n\n\n\t\t\t\t\t";
    for (i = 0; i < 17; i++) {
        std::cout << "\n\t\t\t\t\t";
        for (j = 0; j < 49; j++) {
            std::cout << depos[i][j];
        }
    }
    coordinates.X = 55;
    coordinates.Y = 16;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << logged_account.iban;
    do {
        coordinates.X = 62;
        coordinates.Y = 19;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
        std::cin >> amount;
    } while (amount > 15000 || amount <= 0);
    logged_account.balance += amount;
    coordinates.X = 40;
    coordinates.Y = 23;
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    for (j = 0; j < 2; j++) {
        for (i = 0; i < 4; i++) {
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
            if (i == 0) {
                std::cout << "Processing Details   ";
            }
            else if (i == 1) {
                std::cout << "Processing Details.  ";
            }
            else if (i == 2) {
                std::cout << "Processing Details.. ";
            }
            else if (i == 3) {
                std::cout << "Processing Details...";
            }
            Sleep(250);
        }
    }
    for (j = 0; j < 2; j++) {
        for (i = 0; i < 4; i++) {
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
            if (i == 0) {
                std::cout << "Preparing transaction   ";
            }
            else if (i == 1) {
                std::cout << "Preparing transaction.  ";
            }
            else if (i == 2) {
                std::cout << "Preparing transaction.. ";
            }
            else if (i == 3) {
                std::cout << "Preparing transaction...";
            }
            Sleep(250);
        }
    }
    for (j = 0; j < 2; j++) {
        for (i = 0; i < 4; i++) {
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
            if (i == 0) {
                std::cout << "Performing data analysis   ";
            }
            else if (i == 1) {
                std::cout << "Performing data analysis.  ";
            }
            else if (i == 2) {
                std::cout << "Performing data analysis.. ";
            }
            else if (i == 3) {
                std::cout << "Performing data analysis...";
            }
            Sleep(250);
        }
    }

    for (j = 0; j < 2; j++) {
        for (i = 0; i < 4; i++) {
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
            if (i == 0) {
                std::cout << "Updating database                      ";
            }
            else if (i == 1) {
                std::cout << "Updating database.                  ";
            }
            else if (i == 2) {
                std::cout << "Updating database..                    ";
            }
            else if (i == 3) {
                std::cout << "Updating database...                 ";
            }
            Sleep(250);
        }
    }
    int tcode[3];
    srand(time(NULL));
    for (i = 0; i < 3; i++) {
        tcode[i] = rand() % 8999 + 1000;
    }
    coordinates.X = 40;
    coordinates.Y = 24;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "Successfully deposited " << amount << "$ to " << logged_account.iban;
    coordinates.X = 40;
    coordinates.Y = 25;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "Transaction Code :  ";
    for (i = 0; i < 3; i++) {
        std::cout << tcode[i];
    }

    t_code = std::to_string(tcode[0]) + std::to_string(tcode[1]) + std::to_string(tcode[2]);

    std::time_t currentTime = std::time(nullptr);
    std::tm localTime;
    localtime_s(&localTime, &currentTime);


    char buffer[80];
    std::strftime(buffer, sizeof(buffer), "%d/%m/%Y %H:%M:%S", &localTime);
    new_tran.username = logged_account.username;
    new_tran.code = t_code;
    new_tran.category = "DEPOSIT";
    new_tran.amount = amount;
    new_tran.timedate = buffer;
    new_tran.username2 = "none";

    coordinates.X = 40;
    coordinates.Y = 26;
    for (i = 0; i < 8; i++) {
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
        std::cout << "Returning Home in " << 8 - i;
        Sleep(1000);
    }

}
//withdraw form-page
void withdraw(nbg_account& logged_account, std::vector<transactions>& trans, std::string& t_code, double& amount, transactions& new_tran, std::vector<nbg_account> accounts, int ti) {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");
    int i, j;
    COORD coordinates;

    coordinates.X = 40;
    coordinates.Y = 5;
    std::cout << "\n\n\n\n\t\t\t\t\t";
    for (i = 0; i < 17; i++) {
        std::cout << "\n\t\t\t\t\t";
        for (j = 0; j < 49; j++) {
            std::cout << withdr[i][j];
        }
    }
    coordinates.X = 55;
    coordinates.Y = 16;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << logged_account.iban;
    do {
        coordinates.X = 62;
        coordinates.Y = 19;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
        std::cin >> amount;
    } while ((amount > 2000 || amount <= 0) || (amount > logged_account.balance));
    logged_account.balance -= amount;
    coordinates.X = 40;
    coordinates.Y = 23;
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    for (j = 0; j < 2; j++) {
        for (i = 0; i < 4; i++) {
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
            if (i == 0) {
                std::cout << "Executing transaction   ";
            }
            else if (i == 1) {
                std::cout << "Executing transaction.  ";
            }
            else if (i == 2) {
                std::cout << "Executing transaction.. ";
            }
            else if (i == 3) {
                std::cout << "Executing transaction...";
            }
            Sleep(250);
        }
    }
    for (j = 0; j < 2; j++) {
        for (i = 0; i < 4; i++) {
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
            if (i == 0) {
                std::cout << "Maintaining security and privacy   ";
            }
            else if (i == 1) {
                std::cout << "Maintaining security and privacy.  ";
            }
            else if (i == 2) {
                std::cout << "Maintaining security and privacy.. ";
            }
            else if (i == 3) {
                std::cout << "Maintaining security and privacy...";
            }
            Sleep(250);
        }
    }
    for (j = 0; j < 2; j++) {
        for (i = 0; i < 4; i++) {
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
            if (i == 0) {
                std::cout << "Awaiting transaction confirmation                  ";
            }
            else if (i == 1) {
                std::cout << "Awaiting transaction confirmation.                  ";
            }
            else if (i == 2) {
                std::cout << "Awaiting transaction confirmation..                ";
            }
            else if (i == 3) {
                std::cout << "Awaiting transaction confirmation...               ";
            }
            Sleep(250);
        }
    }

    for (j = 0; j < 2; j++) {
        for (i = 0; i < 4; i++) {
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
            if (i == 0) {
                std::cout << "Generating snapshot                      ";
            }
            else if (i == 1) {
                std::cout << "Generating snapshot.                      ";
            }
            else if (i == 2) {
                std::cout << "Generating snapshot..                     ";
            }
            else if (i == 3) {
                std::cout << "Generating snapshot...                        ";
            }
            Sleep(250);
        }
    }
    int tcode[3];
    srand(time(NULL));
    for (i = 0; i < 3; i++) {
        tcode[i] = rand() % 8999 + 1000;
    }
    coordinates.X = 40;
    coordinates.Y = 24;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "Successfully withdrew " << amount << "$ from " << logged_account.iban;
    coordinates.X = 40;
    coordinates.Y = 25;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "Transaction Code :  ";
    for (i = 0; i < 3; i++) {
        std::cout << tcode[i];
    }

    t_code = std::to_string(tcode[0]) + std::to_string(tcode[1]) + std::to_string(tcode[2]);

    std::time_t currentTime = std::time(nullptr);
    std::tm localTime;
    localtime_s(&localTime, &currentTime);


    char buffer[80];
    std::strftime(buffer, sizeof(buffer), "%d/%m/%Y %H:%M:%S", &localTime);
    new_tran.username = logged_account.username;
    new_tran.code = t_code;
    new_tran.category = "WITHDRAW";
    new_tran.amount = amount;
    new_tran.timedate = buffer;
    new_tran.username2 = "none";

    coordinates.X = 40;
    coordinates.Y = 26;
    for (i = 0; i < 8; i++) {
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
        std::cout << "Returning Home in " << 8 - i;
        Sleep(1000);
    }
}
//transactions page-show history-recent
void show_transactions(std::vector<transactions> trans, nbg_account logged_account, std::string t_code, char dep) {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO consoleInfo;
    GetConsoleScreenBufferInfo(hConsole, &consoleInfo);
    WORD originalColor = consoleInfo.wAttributes;
    std::string date = "00/00/0000", date2;
    bool still = true;
    if (dep == '3') {
        system("cls");
        std::cout << "\n\n\t\t\tYOUR LAST 5 TRANSACTIONS | PRESS '0' TO LEAVE";
        if (trans.size() >= 5) {
            for (int i = (trans.size() - 1); i >= trans.size() - 5; i--) {
                if (trans[i].username == logged_account.username) {


                    if (date[0] != trans[i].timedate[0] || date[1] != trans[i].timedate[1] || date[3] != trans[i].timedate[3] || date[4] != trans[i].timedate[4]) {
                        std::cout << "\n\n\t\t";
                        for (int c = 0; c < 10; c++) {
                            std::cout << trans[i].timedate[c];
                            date[c] = trans[i].timedate[c];
                        }


                    }
                    if (trans[i].category == "TRANSFER") {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tTo User : " << trans[i].username2;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "-" << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                    else if (trans[i].category == "TRANSFER-TO-MONEY BOX") {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tTo Money Box : " << trans[i].username2;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "-" << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                    else if (trans[i].category == "WITHDRAW") {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "-" << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                    else {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                }
                else if (trans[i].username2 == logged_account.username) {
                    if (date[0] != trans[i].timedate[0] || date[1] != trans[i].timedate[1] || date[3] != trans[i].timedate[3] || date[4] != trans[i].timedate[4]) {
                        std::cout << "\n\n\t\t";
                        for (int c = 0; c < 10; c++) {
                            std::cout << trans[i].timedate[c];
                            date[c] = trans[i].timedate[c];
                        }


                    }
                    if (trans[i].category == "TRANSFER") {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tFrom User : " << trans[i].username;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                    else if (trans[i].category == "TRANSFER-TO-MONEY BOX") {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tTo Money Box : " << trans[i].username2;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "-" << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                    else if (trans[i].category == "WITHDRAW") {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "-" << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                    else {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                }
            }
        }
        else {
            for (int i = (trans.size() - 1); i >= 0; i--) {
                if (trans[i].username == logged_account.username) {
                    if (date[0] != trans[i].timedate[0] || date[1] != trans[i].timedate[1] || date[3] != trans[i].timedate[3] || date[4] != trans[i].timedate[4]) {
                        std::cout << "\n\n\t\t";
                        for (int c = 0; c < 10; c++) {
                            std::cout << trans[i].timedate[c];
                            date[c] = trans[i].timedate[c];
                        }


                    }
                    if (trans[i].category == "TRANSFER") {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tTo User : " << trans[i].username2;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "-" << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                    else if (trans[i].category == "TRANSFER-TO-MONEY BOX") {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tTo Money Box : " << trans[i].username2;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "-" << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                    else if (trans[i].category == "WITHDRAW") {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "-" << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                    else {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                }
                else if (trans[i].username2 == logged_account.username) {
                    if (date[0] != trans[i].timedate[0] || date[1] != trans[i].timedate[1] || date[3] != trans[i].timedate[3] || date[4] != trans[i].timedate[4]) {
                        std::cout << "\n\n\t\t";
                        for (int c = 0; c < 10; c++) {
                            std::cout << trans[i].timedate[c];
                            date[c] = trans[i].timedate[c];
                        }


                    }
                    if (trans[i].category == "TRANSFER") {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tFrom User : " << trans[i].username;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                    else if (trans[i].category == "TRANSFER-TO-MONEY BOX") {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tTo Money Box : " << trans[i].username2;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "-" << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                    else if (trans[i].category == "WITHDRAW") {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "-" << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                    else {
                        std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                        std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                        std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                        std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                        std::cout << "\n\t\t\tAmount : ";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << trans[i].amount << "$";
                        SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                        std::cout << "\n\t\t\tType : " << trans[i].category;
                    }
                }

            }
        }


        COORD coordinates;
        coordinates.X = 70;
        coordinates.Y = 1;

        char leave;

        do {
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
            leave = _getch();
        } while (leave != '0');
    }
    else if (dep == '4') {
        system("cls");
        std::cout << "\n\n\t\t\tTRANSACTIONS HISTORY | PRESS '0' TO LEAVE";

        for (int i = (trans.size() - 1); i >= 0; i--) {
            if (trans[i].username == logged_account.username) {



                if (date[0] != trans[i].timedate[0] || date[1] != trans[i].timedate[1] || date[3] != trans[i].timedate[3] || date[4] != trans[i].timedate[4]) {
                    std::cout << "\n\n\t\t";
                    for (int c = 0; c < 10; c++) {
                        std::cout << trans[i].timedate[c];
                        date[c] = trans[i].timedate[c];
                    }


                }
                if (trans[i].category == "TRANSFER") {
                    std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                    std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                    std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                    std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                    std::cout << "\n\t\t\tTo User : " << trans[i].username2;
                    std::cout << "\n\t\t\tAmount : ";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << "-" << trans[i].amount << "$";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << "\n\t\t\tType : " << trans[i].category;
                }
                else if (trans[i].category == "TRANSFER-TO-MONEY BOX") {
                    std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                    std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                    std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                    std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                    std::cout << "\n\t\t\tTo Money Box : " << trans[i].username2;
                    std::cout << "\n\t\t\tAmount : ";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << "-" << trans[i].amount << "$";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << "\n\t\t\tType : " << trans[i].category;
                }
                else if (trans[i].category == "WITHDRAW") {
                    std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                    std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                    std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                    std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                    std::cout << "\n\t\t\tAmount : ";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << "-" << trans[i].amount << "$";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << "\n\t\t\tType : " << trans[i].category;
                }
                else {
                    std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                    std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                    std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                    std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                    std::cout << "\n\t\t\tAmount : ";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << trans[i].amount << "$";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << "\n\t\t\tType : " << trans[i].category;
                }
            }
            else if (trans[i].username2 == logged_account.username) {
                if (date[0] != trans[i].timedate[0] || date[1] != trans[i].timedate[1] || date[3] != trans[i].timedate[3] || date[4] != trans[i].timedate[4]) {
                    std::cout << "\n\n\t\t";
                    for (int c = 0; c < 10; c++) {
                        std::cout << trans[i].timedate[c];
                        date[c] = trans[i].timedate[c];
                    }


                }
                if (trans[i].category == "TRANSFER") {
                    std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                    std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                    std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                    std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                    std::cout << "\n\t\t\tFrom User : " << trans[i].username;
                    std::cout << "\n\t\t\tAmount : ";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << trans[i].amount << "$";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << "\n\t\t\tType : " << trans[i].category;
                }
                else if (trans[i].category == "TRANSFER-TO-MONEY BOX") {
                    std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                    std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                    std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                    std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                    std::cout << "\n\t\t\tTo Money Box : " << trans[i].username2;
                    std::cout << "\n\t\t\tAmount : ";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << "-" << trans[i].amount << "$";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << "\n\t\t\tType : " << trans[i].category;
                }
                else if (trans[i].category == "WITHDRAW") {
                    std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                    std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                    std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                    std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                    std::cout << "\n\t\t\tAmount : ";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << "-" << trans[i].amount << "$";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << "\n\t\t\tType : " << trans[i].category;
                }
                else {
                    std::cout << "\n\t\t\t_________________________________\n\t\t\t";
                    std::cout << trans[i].timedate[11] << trans[i].timedate[12] << trans[i].timedate[13] << trans[i].timedate[14] << trans[i].timedate[15] << trans[i].timedate[16] << trans[i].timedate[17] << trans[i].timedate[18];
                    std::cout << "\n\t\t\tOwner : " << logged_account.first_name[0] << "." << logged_account.last_name;
                    std::cout << "\n\t\t\tTransaction Code : " << trans[i].code;
                    std::cout << "\n\t\t\tAmount : ";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << trans[i].amount << "$";
                    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
                    std::cout << "\n\t\t\tType : " << trans[i].category;
                }
            }

        }

        COORD coordinates;
        coordinates.X = 70;
        coordinates.Y = 1;

        char leave;

        do {
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
            leave = _getch();
        } while (leave != '0');
    }

    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
}
//transfer form-page
void transfer(std::vector<nbg_account>& accounts, nbg_account& logged_account, nbg_account transfer_account, std::vector<transactions>& trans, std::string& t_code, double& amount, transactions& new_tran, int& ti) {

    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");
    int i, j;

    COORD coordinates;
    coordinates.X = 40;
    coordinates.Y = 50;
    std::cout << "\n\n\n";
    for (i = 0; i < TRANSFER_HEIGHT; i++) {
        std::cout << "\n\t\t\t\t\t";
        for (j = 0; j < TRANSFER_WIDTH; j++) {
            std::cout << transfr[i][j];
        }
    }
    coordinates.X = 50;
    coordinates.Y = 14;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << logged_account.iban;
    coordinates.Y = 18;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << accounts[ti].iban;
    do {
        coordinates.X = 62;
        coordinates.Y = 21;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
        std::cin >> amount;
    } while ((amount > 100000 || amount <= 0) || (amount > logged_account.balance));
    logged_account.balance -= amount;
    accounts[ti].balance += amount;

    coordinates.X = 40;
    coordinates.Y = 25;
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    for (j = 0; j < 2; j++) {
        for (i = 0; i < 4; i++) {
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
            if (i == 0) {
                std::cout << "Executing transaction   ";
            }
            else if (i == 1) {
                std::cout << "Executing transaction.  ";
            }
            else if (i == 2) {
                std::cout << "Executing transaction.. ";
            }
            else if (i == 3) {
                std::cout << "Executing transaction...";
            }
            Sleep(250);
        }
    }
    for (j = 0; j < 2; j++) {
        for (i = 0; i < 4; i++) {
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
            if (i == 0) {
                std::cout << "Maintaining security and privacy   ";
            }
            else if (i == 1) {
                std::cout << "Maintaining security and privacy.  ";
            }
            else if (i == 2) {
                std::cout << "Maintaining security and privacy.. ";
            }
            else if (i == 3) {
                std::cout << "Maintaining security and privacy...";
            }
            Sleep(250);
        }
    }
    for (j = 0; j < 2; j++) {
        for (i = 0; i < 4; i++) {
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
            if (i == 0) {
                std::cout << "Awaiting transaction confirmation                  ";
            }
            else if (i == 1) {
                std::cout << "Awaiting transaction confirmation.                  ";
            }
            else if (i == 2) {
                std::cout << "Awaiting transaction confirmation..                ";
            }
            else if (i == 3) {
                std::cout << "Awaiting transaction confirmation...               ";
            }
            Sleep(250);
        }
    }

    for (j = 0; j < 2; j++) {
        for (i = 0; i < 4; i++) {
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
            if (i == 0) {
                std::cout << "Generating snapshot                      ";
            }
            else if (i == 1) {
                std::cout << "Generating snapshot.                      ";
            }
            else if (i == 2) {
                std::cout << "Generating snapshot..                     ";
            }
            else if (i == 3) {
                std::cout << "Generating snapshot...                        ";
            }
            Sleep(250);
        }
    }
    int tcode[3];
    srand(time(NULL));
    for (i = 0; i < 3; i++) {
        tcode[i] = rand() % 8999 + 1000;
    }
    coordinates.X = 40;
    coordinates.Y = 24;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "Successfully transfered " << amount << "$";
    coordinates.X = 40;
    coordinates.Y = 25;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "Transaction Code :  ";
    for (i = 0; i < 3; i++) {
        std::cout << tcode[i];
    }

    t_code = std::to_string(tcode[0]) + std::to_string(tcode[1]) + std::to_string(tcode[2]);

    std::time_t currentTime = std::time(nullptr);
    std::tm localTime;
    localtime_s(&localTime, &currentTime);


    char buffer[80];
    std::strftime(buffer, sizeof(buffer), "%d/%m/%Y %H:%M:%S", &localTime);
    new_tran.username = logged_account.username;
    new_tran.code = t_code;
    new_tran.category = "TRANSFER-TO-MONEY BOX";
    new_tran.amount = amount;
    new_tran.timedate = buffer;
    new_tran.username2 = accounts[ti].username;
    coordinates.X = 40;
    coordinates.Y = 26;
    for (i = 0; i < 8; i++) {
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
        std::cout << "Returning Home in " << 8 - i;
        Sleep(1000);
    }
}
//user select to which other user he will transfer
void transfer_to(std::vector<nbg_account> accounts, int& ti) {

    int i;
    std::string tusername;
    bool found = false;
    do {
        system("cls");
        std::cout << "\n\n\n\n\n\t\t\t\t\t\tTransfer to(username) : ";
        std::cin >> tusername;
        for (i = 0; i < accounts.size(); i++) {
            if (tusername == accounts[i].username) {
                found = true;
                ti = i;
                break;
            }
            else {

                found = false;
            }
        }
        if (found == false) {
            std::cout << "\n\n\t\t\t\tWe couldnt find the username you typed ,Try again...";
            Sleep(2500);
        }
    } while (found != true);
}
//create money box form-page
void create_moneybox(std::vector<money_boxes> &boxes,nbg_account logged_account) {
    std::string con;
    do {
        system("cls");
        std::cout << "\n\n\n\n\n\t\t\t\t\tWARNING! You can have only 1 Money Box ,if you create";
        std::cout << "\n\t\t\t\t\ta new one,the last Money Box will be DELETED!";
        std::cout << "\n\n\t\t\t\t\tDo you want to continue?(yes or no) ";
        std::cin >> con;
    } while (con != "yes" && con != "YES" && con != "Yes" && con != "yEs" && con != "yeS" && con != "yES" && con != "YEs" && con != "YeS" && con != "YeS" && con != "no" && con != "NO" && con != "No" && con != "nO");
    if (con == "no" || con == "NO" || con == "No" || con == "nO") {
        return;
    }
    int i, j;
    std::string submit;
    COORD coordinates;

    do {
        system("cls");
        std::cout << "\n\t\t\t\t\t\tNATIONAL BANK OF GREECE";
        std::cout << "\n\n\t\t\t\t\t\tCreate a Money Box";
        std::cout << "\n\n\t\t\t\t\t\tName (required) : ";

        for (i = 0; i < 3; i++) {
            std::cout << "\n\t\t\t\t\t\t";
            for (j = 0; j < 23; j++) {
                std::cout << form[i][j];
            }
        }

        std::cout << "\n";
        std::cout << "\n\t\t\t\t\t\tCategory (required) : ";

        for (i = 0; i < 3; i++) {
            std::cout << "\n\t\t\t\t\t\t";
            for (j = 0; j < 23; j++) {
                std::cout << form[i][j];
            }
        }

        std::cout << "\n";
        std::cout << "\n\t\t\t\t\t\tGoal(required) : ";

        for (i = 0; i < 3; i++) {
            std::cout << "\n\t\t\t\t\t\t";
            for (j = 0; j < 23; j++) {
                std::cout << form[i][j];
            }
        }

        std::cout << "\n";
        std::cout << "\n\t\t\t\t\t\tEnd Date(required) : ";

        for (i = 0; i < 3; i++) {
            std::cout << "\n\t\t\t\t\t\t";
            for (j = 0; j < 23; j++) {
                std::cout << form[i][j];
            }
        }

        std::cout << "\n";
        std::cout << "\n\t\t\t\t\t\tCREATE(TYPE 'YES') : ";
        std::cout << "\n";

        coordinates.X = 52;
        coordinates.Y = 7;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
        money_boxes box;
        std::cin >> box.box_name;
  
        coordinates.Y = 12;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);

        std::cin >> box.category;
 
        coordinates.Y = 17;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);

            std::cin >> box.end_amount;
            box.user = logged_account.username;
        coordinates.Y = 22;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
        std::cin >> box.date;
        boxes.pop_back();
        boxes.push_back(box);
        coordinates.X = 69;
        coordinates.Y = 25;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
        std::cin >> submit;
    } while (submit != "yes" && submit != "YES" && submit != "Yes" && submit != "YeS" && submit != "yES" && submit != "yEs");
    
}
//MONEY BOXES
void money_box(std::vector<nbg_account>& accounts, nbg_account& logged_account, nbg_account transfer_account, std::vector<transactions>& trans, std::string& t_code, double& amount, transactions& new_tran, int& ti,char &k,std::vector<money_boxes> &boxes) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO consoleInfo;
    GetConsoleScreenBufferInfo(hConsole, &consoleInfo);
    WORD originalColor = consoleInfo.wAttributes;
    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    system("cls");
    std::cout << "\n\t\t\t\t\t\tPress '1' to transfer to your Money Box | Press '0' to exit...\n\n";
    for (int i = 0; i < MBOX_HEIGHT; i++) {
        std::cout << "\n\t\t\t\t\t";
        for (int j = 0; j < MBOX_WIDTH; j++) {
            if (mbox[i][j] == '|' || mbox[i][j] == '_') {
                SetConsoleTextAttribute(hConsole, 17);
                std::cout << mbox[i][j];
            }
            else {
                SetConsoleTextAttribute(hConsole, 159);
                std::cout << mbox[i][j];
            }
        }
    }
    SetConsoleTextAttribute(hConsole, 159);
    COORD coordinates;
    coordinates.X = 48;
    coordinates.Y = 7;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << boxes[0].box_name;
    coordinates.Y = 10;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << boxes[0].end_amount;
    coordinates.Y = 13;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << boxes[0].today_amount;
    coordinates.Y = 16;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << boxes[0].date;

    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    
    int i, j;
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    coordinates.X = 45;
    coordinates.Y = 19;
    do {
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
        k = _getch();
    } while (k != '1' && k != '0');
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    double t_amount;
    switch (k) {
        case '0':break;
        case '1':coordinates.X = 45;
                 coordinates.Y = 19;
                 do {
                     SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
                     std::cout << "Amount to Save :                 ";
                     coordinates.X = 62;
                     SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
                     std::cin >> t_amount;
                 } while (t_amount <= 0 || t_amount > (boxes[0].end_amount - boxes[0].today_amount));
                 boxes[0].today_amount += t_amount;
                 logged_account.balance -= t_amount;
                 coordinates.X = 40;
                 coordinates.Y = 25;
                 cursorInfo.bVisible = false;
                 SetConsoleCursorInfo(consoleHandle, &cursorInfo);
                 for (j = 0; j < 2; j++) {
                     for (i = 0; i < 4; i++) {
                         SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
                         if (i == 0) {
                             std::cout << "Executing transaction   ";
                         }
                         else if (i == 1) {
                             std::cout << "Executing transaction.  ";
                         }
                         else if (i == 2) {
                             std::cout << "Executing transaction.. ";
                         }
                         else if (i == 3) {
                             std::cout << "Executing transaction...";
                         }
                         Sleep(250);
                     }
                 }
                 for (j = 0; j < 2; j++) {
                     for (i = 0; i < 4; i++) {
                         SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
                         if (i == 0) {
                             std::cout << "Maintaining security and privacy   ";
                         }
                         else if (i == 1) {
                             std::cout << "Maintaining security and privacy.  ";
                         }
                         else if (i == 2) {
                             std::cout << "Maintaining security and privacy.. ";
                         }
                         else if (i == 3) {
                             std::cout << "Maintaining security and privacy...";
                         }
                         Sleep(250);
                     }
                 }
                 for (j = 0; j < 2; j++) {
                     for (i = 0; i < 4; i++) {
                         SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
                         if (i == 0) {
                             std::cout << "Awaiting transaction confirmation                  ";
                         }
                         else if (i == 1) {
                             std::cout << "Awaiting transaction confirmation.                  ";
                         }
                         else if (i == 2) {
                             std::cout << "Awaiting transaction confirmation..                ";
                         }
                         else if (i == 3) {
                             std::cout << "Awaiting transaction confirmation...               ";
                         }
                         Sleep(250);
                     }
                 }

                 for (j = 0; j < 2; j++) {
                     for (i = 0; i < 4; i++) {
                         SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
                         if (i == 0) {
                             std::cout << "Generating snapshot                      ";
                         }
                         else if (i == 1) {
                             std::cout << "Generating snapshot.                      ";
                         }
                         else if (i == 2) {
                             std::cout << "Generating snapshot..                     ";
                         }
                         else if (i == 3) {
                             std::cout << "Generating snapshot...                        ";
                         }
                         Sleep(250);
                     }
                 }
                 int tcode[3];
                 srand(time(NULL));
                 for (i = 0; i < 3; i++) {
                     tcode[i] = rand() % 8999 + 1000;
                 }
                 coordinates.X = 40;
                 coordinates.Y = 24;
                 SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
                 std::cout << "Successfully transfered " << t_amount << "$ to " << boxes[0].box_name;
                 coordinates.X = 40;
                 coordinates.Y = 25;
                 SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
                 std::cout << "Transaction Code :  ";
                 for (i = 0; i < 3; i++) {
                     std::cout << tcode[i];
                 }

                 t_code = std::to_string(tcode[0]) + std::to_string(tcode[1]) + std::to_string(tcode[2]);

                 std::time_t currentTime = std::time(nullptr);
                 std::tm localTime;
                 localtime_s(&localTime, &currentTime);


                 char buffer[80];
                 std::strftime(buffer, sizeof(buffer), "%d/%m/%Y %H:%M:%S", &localTime);
                 new_tran.username = logged_account.username;
                 new_tran.code = t_code;
                 new_tran.category = "TRANSFER-TO-MONEY BOX";
                 new_tran.amount = t_amount;
                 new_tran.timedate = buffer;
                 new_tran.username2 = boxes[0].box_name;
                 coordinates.X = 40;
                 coordinates.Y = 26;
                 for (i = 0; i < 8; i++) {
                     SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
                     std::cout << "Returning Home in " << 8 - i;
                     Sleep(1000);
                 }
                 break;
    }

}
//the loading screen when user creates successfully a money box
void creating_moneybox_loading() {
   
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");
    SetConsoleCP(437);
    SetConsoleOutputCP(437);
    int bar1 = 177, bar2 = 219;

    std::cout << "\n\n\n\t\t\t\t\t\tNATIONAL BANK OF GREECE\n\n\n\n";
    std::cout << "\t\t\t\t\t\tCreating the Money Box...";
    std::cout << "\n\n\n\t\t\t\t\t\t";

    for (int i = 0; i < 25; i++) {
        std::cout << (char)bar1;
    }

    std::cout << "\r";
    std::cout << "\t\t\t\t\t\t";
    for (int i = 0; i < 25; i++) {
        std::cout << (char)bar2;
        Sleep(150);
    }

    system("cls");
    COORD coordinates;
    coordinates.X = 46;
    coordinates.Y = 8;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "Money Box Created!!";
    Sleep(2500);
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
}
//statistics funtion
void statistics(double total_earn,double total_spent,float transfer_pos,float withdraw_pos,float money_box_pos) {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO consoleInfo;
    GetConsoleScreenBufferInfo(hConsole, &consoleInfo);
    WORD originalColor = consoleInfo.wAttributes;
    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    COORD coordinates;
    coordinates.X =45;
    coordinates.Y = 3;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    std::cout << "-- All Time Statistics --      |   Press Any Key to exit..";
    coordinates.X = 30;
    coordinates.Y = 7;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    std::cout << "Aggregated View ";
    coordinates.X = 35;
    coordinates.Y = 9;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    SetConsoleTextAttribute(hConsole, FOREGROUND_GREEN | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    std::cout << "Total Earn -> " << total_earn << "$";
    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    coordinates.X = 35;
    coordinates.Y = 11;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    std::cout << "Total Spent -> -" << total_spent << "$";
    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    coordinates.X = 30;
    coordinates.Y = 13;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    std::cout << "Spending Categories" ;
    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    coordinates.X = 35;
    coordinates.Y = 15;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    std::cout << "Withdraws " << std::setprecision(4) << withdraw_pos << "%";
    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    coordinates.X = 35;
    coordinates.Y = 17;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    std::cout << "Transfers to others " << std::setprecision(4) << transfer_pos << "%";
    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    coordinates.X = 35;
    coordinates.Y = 19;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    std::cout << "Transfers to Money Boxes " << std::setprecision(4) <<money_box_pos << "%";
    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    coordinates.X = 30;
    coordinates.Y = 1;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);

    char k;
    k = _getch();
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
}
//MAIN
int main() {

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO consoleInfo;
    GetConsoleScreenBufferInfo(hConsole, &consoleInfo);
    WORD originalColor = consoleInfo.wAttributes;
    SetConsoleTextAttribute(hConsole, FOREGROUND_BLUE | BACKGROUND_INTENSITY | BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED);
    get_form();
    get_deposit();
    get_withdraw();
    get_transfer();
    get_moneybox();
    open_loading_screen();
    std::string first_name, last_name, username, password;
    char create;
    COORD coordinates;
    bool flag;
    std::vector<nbg_account> accounts;
    std::vector<transactions> trans;
    std::vector<money_boxes> boxes;
    int acc_i;
    load_accounts(accounts);

    nbg_account logged_account;
    transactions new_tran;
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    //login or create an account choice screen
    do {
        system("cls");
        std::cout << "\n\n\n\t\t\t\t\t\t- NATIONAL BANK OF GREECE -\n\n\n";
        std::cout << "\t\t\t\t\t   ---- To Create an ACCOUNT PRESS 1 ----\n\n";
        std::cout << "\t\t\t\t\t   ---- To LOGIN PRESS 2 ----";
        coordinates.X = 57;
        coordinates.Y = 14;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
        create = _getch();
    } while (create != '1' && create != '2');

    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    //after user choose an option ,he gets directed to the page he chose
    if (create == '1') {
        nbg_account new_account;
        create_account(new_account, logged_account);
        accounts.push_back(new_account);
        creating_loading(new_account);
        save_account(accounts);
        acc_i = accounts.size() - 1;
    }
    else {
        login(accounts, logged_account, acc_i);
        login_loading(logged_account);
    }
    char dep;
    int ti;
    std::string t_code;
    double amount;
    load_transactions(trans);
    load_moneyboxes(boxes);
    nbg_account transfer_account;
    //showing the app after create or login to an account
    char k;
    float total_earn=0, total_spent=0, transfer_pos=0, withdraw_pos=0, money_box_pos=0, x;
    float pl = 0;
    char sev = '7';
    do {
        system("cls");

        show_app(logged_account, trans);
        cursorInfo.bVisible = false;
        SetConsoleCursorInfo(consoleHandle, &cursorInfo);
        do {
            dep = _getch();
        } while (dep != '1' && dep != '2' && dep != '0' && dep != '3' && dep != '4' && dep != '5' && dep != '6' && dep != '7' && dep!='8');

        cursorInfo.bVisible = true;
        SetConsoleCursorInfo(consoleHandle, &cursorInfo);

        switch (dep) {
        case'1':
            ;
            deposit(logged_account, trans, t_code, amount, new_tran, accounts, ti);
            trans.push_back(new_tran);
            save_transactions(trans, t_code, dep, logged_account, amount);
            accounts[acc_i].balance = logged_account.balance;
            show_app(logged_account, trans);
            break;
        case'2':

            withdraw(logged_account, trans, t_code, amount, new_tran, accounts, ti);
            trans.push_back(new_tran);
            save_transactions(trans, t_code, dep, logged_account, amount);
            accounts[acc_i].balance = logged_account.balance;
            show_app(logged_account, trans);
            break;
        case '3':show_transactions(trans, logged_account, t_code, dep);
            show_app(logged_account, trans);
            break;
        case '4':show_transactions(trans, logged_account, t_code, dep);
            show_app(logged_account, trans);
            break;
        case '5':transfer_to(accounts, ti);
            transfer(accounts, logged_account, transfer_account, trans, t_code, amount, new_tran, ti);
            trans.push_back(new_tran);
            save_transactions(trans, t_code, dep, logged_account, amount);
            accounts[acc_i].balance = logged_account.balance;
            show_app(logged_account, trans);
            break;
        case '6':money_box(accounts, logged_account, transfer_account, trans, t_code, amount, new_tran, ti,k,boxes);
                if (k == '1') {          
                    trans.push_back(new_tran);
                    save_transactions(trans, t_code, dep, logged_account, amount);
                    accounts[acc_i].balance = logged_account.balance;
                }
                show_app(logged_account, trans);
                 break;
        case '7':create_moneybox(boxes, logged_account);
                 creating_moneybox_loading();
                 save_moneyboxes(boxes,logged_account);                
                 money_box(accounts, logged_account, transfer_account, trans, t_code, amount, new_tran, ti, k, boxes);
                 if (k == '1') {
                     trans.push_back(new_tran);
                     save_transactions(trans, t_code, dep, logged_account, amount);
                     accounts[acc_i].balance = logged_account.balance;
                 }
                 show_app(logged_account, trans);
                 break;
        case '8':for (int g = 0; g < trans.size(); g++) {
                     if (trans[g].username == logged_account.username ) {
                         
                         if (trans[g].category == "WITHDRAW") {
                             withdraw_pos++;
                             total_spent += trans[g].amount; 
                             pl++;
                         }
                         if (trans[g].category == "TRANSFER") {
                             transfer_pos++;
                             total_spent += trans[g].amount;
                             pl++;
                         }
                         if (trans[g].category == "TRANSFER-TO-MONEY BOX") {
                             money_box_pos++;
                             total_spent += trans[g].amount;
                             pl++;
                         }
                         else if (trans[g].category == "DEPOSIT") {
                             total_earn += trans[g].amount;
                         }
                     }
                 }
                 x = 100 / pl;
                 pl = 100;
                 withdraw_pos *= x;
                 transfer_pos *= x;
                 money_box_pos *= x;
                 statistics(total_earn, total_spent, transfer_pos, withdraw_pos, money_box_pos);
                 show_app(logged_account, trans);
                 break;
        }
        save_account(accounts);
    } while (dep != '0');


    return 0;
}